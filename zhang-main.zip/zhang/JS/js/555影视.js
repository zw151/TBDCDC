var rule = Object.assign(muban.mxpro,{
title:'555影视',
// host:'https://www.555ys3.com/',
host:'https://www.555pian.com',
headers:{//网站的请求头,完整支持所有的,常带ua和cookies
    'User-Agent':'MOBILE_UA',
    "Cookie": "searchneed=ok"
},
});